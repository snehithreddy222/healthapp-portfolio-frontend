import AppShell from "../../components/common/AppShell";
export default function AuditLogs(){ return <AppShell title="Audit Logs"><div className="bg-white border rounded-xl p-6">Logs table…</div></AppShell>; }
