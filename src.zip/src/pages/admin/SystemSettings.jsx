import AppShell from "../../components/common/AppShell";
export default function SystemSettings(){ return <AppShell title="System Settings"><div className="bg-white border rounded-xl p-6">Security & retention forms…</div></AppShell>; }
