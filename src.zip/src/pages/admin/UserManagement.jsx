import AppShell from "../../components/common/AppShell";
export default function UserManagement(){ return <AppShell title="User Management"><div className="bg-white border rounded-xl p-6">Table coming next…</div></AppShell>; }
