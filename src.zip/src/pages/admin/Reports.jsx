import AppShell from "../../components/common/AppShell";
export default function Reports(){ return <AppShell title="Reports"><div className="bg-white border rounded-xl p-6">Report builder…</div></AppShell>; }
